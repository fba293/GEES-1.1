import React, { useEffect, useRef, useState } from 'react';
import { Search, Mic, ChevronDown, ChevronUp, X } from 'lucide-react';
import { COURSE_SUBJECTS } from './course-subjects.ts';
import { mockUniversities } from '../../data/mockDatabase.ts';
import { APPROVED_COUNTRY_NAMES } from '../../lib/country-config.ts';

type Tab = 'Courses' | 'Scholarships' | 'Universities' | 'All Services';
type Filter = 'level' | 'destination' | 'field';
interface Props { onNavigate: (view: string, payload?: any) => void; }

// The duplicate "Tourist Visa" is intentional; it appears twice in the user's rotation sequence.
const ROTATING_SERVICES = [
  'Universities','Courses','Countries','Cities','Scholarships','Accommodation',
  'Student Visa','Tourist Visa','Family Visa','Admission Support','School Admission',
  'Student Referral','Dependent Visa','Tourist Visa','MM2H Program','Health Insurance',
  'Flight Ticketing','Airport Pickup','Tour Packages','Car Rental','Courier Services',
  'Airbnb / Short Stay','Money Transfer','IELTS Preparation','PTE Preparation',
  'Linguaskill Prep','B2B Partnership'
];
const GROUPS: Record<string, string[]> = {
  Education: ['Universities','Courses','Countries','Cities','Scholarships','Admission Support','School Admission','Student Referral'],
  Visas: ['Student Visa','Tourist Visa','Family Visa','Dependent Visa','MM2H Program'],
  Travel: ['Accommodation','Flight Ticketing','Airport Pickup','Tour Packages','Car Rental','Airbnb / Short Stay'],
  Language: ['IELTS Preparation','PTE Preparation','Linguaskill Prep'],
  Other: ['Health Insurance','Courier Services','Money Transfer','B2B Partnership'],
};
const LEVELS = ['School','English','Diploma','Foundation / Pathways','Undergraduate (Bachelor’s)','Postgraduate (Master’s)','Doctorate (PhD)','Vocational (VET)'];
// Keep the destination names from the actual website registry unchanged.
const DESTINATIONS: string[] = [...APPROVED_COUNTRY_NAMES].sort((a,b)=>a.localeCompare(b));
const UNIVERSITIES = [...new Set(mockUniversities.map(u=>u.name))].sort((a,b)=>a.localeCompare(b));
const LEVEL_MAP: Record<string,string> = {
  'School':'school','English':'english','Diploma':'diploma',
  'Foundation / Pathways':'foundation','Undergraduate (Bachelor’s)':'undergraduate',
  'Postgraduate (Master’s)':'postgraduate','Doctorate (PhD)':'doctorate',
  'Vocational (VET)':'vocational'
};
const SERVICE_SLUGS: Record<string,string> = {
  'Student Visa':'student-visa','Tourist Visa':'tourist-visa','Family Visa':'family-visa',
  'Dependent Visa':'dependent-visa','MM2H Program':'mm2h',
  'Health Insurance':'health-insurance','Flight Ticketing':'flight-ticketing',
  'Admission Support':'admission-support','School Admission':'school-admission',
  'Student Referral':'student-referral','IELTS Preparation':'ielts-preparation',
  'PTE Preparation':'pte-preparation','Linguaskill Prep':'linguaskill-prep',
};
const summary = (values: string[], empty: string) => values.length===0 ? empty : values.length===1 ? values[0] : `${values.length} selected`;

export const UnifiedHeroSearch: React.FC<Props> = ({onNavigate}) => {
  const [tab,setTab] = useState<Tab>('Courses');
  const [query,setQuery] = useState('');
  const [rotateIndex,setRotateIndex] = useState(0);
  const [reducedMotion,setReducedMotion] = useState(false);
  const [focused,setFocused] = useState(false);
  const [servicesOpen,setServicesOpen] = useState(false);
  const [category,setCategory] = useState('All');
  const [filterOpen,setFilterOpen] = useState<Filter|null>(null);
  const [levels,setLevels] = useState<string[]>([]);
  const [destinations,setDestinations] = useState<string[]>([]);
  const [fields,setFields] = useState<string[]>([]);
  const [fieldQuery,setFieldQuery] = useState('');
  const [university,setUniversity] = useState('');
  const [feedback,setFeedback] = useState('');
  const inputRef=useRef<HTMLInputElement>(null);
  const rootRef=useRef<HTMLDivElement>(null);
  const fieldSearchRef=useRef<HTMLInputElement>(null);
  useEffect(()=>{
    const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
    const update=()=>setReducedMotion(preference.matches);
    update(); preference.addEventListener('change',update);
    return ()=>preference.removeEventListener('change',update);
  },[]);
  useEffect(()=>{
    if(reducedMotion || focused || query) return;
    const interval=window.setInterval(()=>{
      if(document.visibilityState==='visible') setRotateIndex(index=>(index+1)%ROTATING_SERVICES.length);
    },2600);
    return ()=>window.clearInterval(interval);
  },[focused,query,reducedMotion]);
  useEffect(()=>{
    const outside=(event:PointerEvent)=>{
      if(rootRef.current && !rootRef.current.contains(event.target as Node)){
        setFilterOpen(null);setServicesOpen(false);
      }
    };
    const escape=(event:KeyboardEvent)=>{
      if(event.key==='Escape'){setFilterOpen(null);setServicesOpen(false);inputRef.current?.blur();}
    };
    document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return ()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[]);
  useEffect(()=>{if(filterOpen==='field') fieldSearchRef.current?.focus();},[filterOpen]);

  const values: Record<Filter,string[]>={level:levels,destination:destinations,field:fields};
  const setValues: Record<Filter,React.Dispatch<React.SetStateAction<string[]>>>={level:setLevels,destination:setDestinations,field:setFields};
  const options:Record<Filter,string[]>={level:LEVELS,destination:DESTINATIONS,field:COURSE_SUBJECTS};
  const changeTab=(next:Tab)=>{setTab(next);setFilterOpen(null);setServicesOpen(false);setFeedback('');};
  const navigateService=(service:string)=>{
    setServicesOpen(false);setQuery(service);
    if(service==='Universities') return onNavigate('universities');
    if(service==='Courses') return onNavigate('courses');
    if(service==='Scholarships') return changeTab('Scholarships');
    if(service==='Countries'||service==='Cities') return onNavigate('countries');
    onNavigate('services', SERVICE_SLUGS[service] || service.toLowerCase().replace(/\s*\/\s*/g,'-').replace(/\s+/g,'-'));
  };
  const runSearch=()=>{
    setFilterOpen(null);setServicesOpen(false);
    if(tab==='All Services'){
      const matched=ROTATING_SERVICES.find(item=>item.toLowerCase()===query.trim().toLowerCase());
      if(matched) navigateService(matched);
      else if(query.trim()) onNavigate('services');
      else onNavigate('services');
      return;
    }
    if(tab==='Universities'){
      const matching=mockUniversities.find(u=>u.name.toLowerCase()===university.trim().toLowerCase());
      // The current UniversityExplorerView only accepts a slug and does not support prefilter arguments.
      // Preserve its actual navigation contract rather than fabricating functional filters.
      onNavigate('universities', matching?.slug);
      return;
    }
    if(tab==='Scholarships'){
      // The current app exposes scholarship selection within the UniversityExplorerView.
      onNavigate('universities');
      return;
    }
    // Existing app supports single-valued initial filters; preserve the contract.
    onNavigate('courses', {
      query, destination:destinations[0]||'all', level:LEVEL_MAP[levels[0]]||'all', field:fields[0]||'all'
    });
  };
  const matchingServices = [...new Set(category==='All'?ROTATING_SERVICES:GROUPS[category])]
    .filter(s=>s.toLowerCase().includes(query.toLowerCase()));

  const renderFilter=(kind:Filter,label:string,empty:string)=>{
    const open=filterOpen===kind;
    const choices=options[kind].filter(x=>kind!=='field'||x.toLowerCase().includes(fieldQuery.trim().toLowerCase()));
    return <div className="relative min-w-0" key={kind}>
      <button type="button" aria-expanded={open} aria-label={label} onClick={()=>{setFilterOpen(open?null:kind);setServicesOpen(false);}}
        className={`h-16 w-full min-w-0 rounded-xl border ${open?'border-amber-400':'border-slate-200 dark:border-slate-700'} bg-white dark:bg-slate-800 px-3.5 text-left flex items-center justify-between gap-2 transition-colors hover:border-amber-400 focus-visible:outline-2 focus-visible:outline-amber-500`}>
        <span className="min-w-0 flex-1"><span className="block text-[10px] uppercase tracking-wider font-semibold text-slate-400">{label}</span>
          <span className="block truncate text-[15px] font-medium text-slate-800 dark:text-white mt-0.5">{summary(values[kind],empty)}</span></span>
        {open?<ChevronUp size={17} className="shrink-0 text-slate-500"/>:<ChevronDown size={17} className="shrink-0 text-slate-500"/>}
      </button>
      {open&&<div role="group" aria-label={`${label} options`} className="absolute top-[calc(100%+5px)] left-0 z-50 w-[max(100%,290px)] max-w-[min(340px,calc(100vw-40px))] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-1.5 shadow-xl">
        {kind==='field'&&<input ref={fieldSearchRef} value={fieldQuery} onChange={e=>setFieldQuery(e.target.value)} placeholder="Search course subjects..." aria-label="Search course subjects" className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent p-2.5 text-sm outline-none focus:border-amber-400 mb-1"/>}
        <div className="max-h-[260px] overflow-y-auto overscroll-contain [scrollbar-width:thin] [scrollbar-color:#aab3c0_#f1f3f6]">
          {choices.map(option=><label key={option} className="min-h-10 px-2.5 py-1 flex items-center gap-2.5 rounded-md cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
            <input type="checkbox" checked={values[kind].includes(option)} onChange={e=>setValues[kind](current=>e.target.checked?[...current,option]:current.filter(x=>x!==option))} className="h-[20px] w-[20px] shrink-0 accent-amber-500"/>
            <span className="text-[16px] leading-5 text-slate-800 dark:text-slate-100">{option}</span>
          </label>)}
          {choices.length===0&&<p className="p-3 text-sm text-slate-500">No matching subjects.</p>}
        </div>
      </div>}
    </div>;
  };
  return <div ref={rootRef} className="relative z-30 w-full mt-2 sm:mt-5" data-purpose="unified-hero-search-v31">
    <style>{`@keyframes geesServiceRise{0%{transform:translateY(105%);opacity:0}15%{transform:translateY(0);opacity:1}81%{transform:translateY(0);opacity:1}100%{transform:translateY(-110%);opacity:0}}.gees-service-rise{animation:geesServiceRise 2.6s ease-in-out both}@media(prefers-reduced-motion:reduce){.gees-service-rise{animation:none;transform:none;opacity:1}}`}</style>
    <div className="rounded-2xl border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-[0_16px_45px_-26px_rgba(16,35,65,.28)]">
      <div className="relative px-3 sm:px-5 py-3 sm:py-4">
        <div className="flex items-center gap-2.5 h-11 sm:h-12">
          <Search size={22} className="shrink-0 text-amber-500" aria-hidden="true"/>
          <div className="flex-1 min-w-0 relative h-full flex items-center">
            {!query&&!focused&&<div aria-hidden="true" className="absolute inset-0 pointer-events-none flex items-center gap-1.5 overflow-hidden text-sm sm:text-base whitespace-nowrap">
              <span className="font-semibold text-slate-800 dark:text-white shrink-0">Search</span>
              <span className="relative overflow-hidden h-7 flex-1 min-w-0 text-slate-400 dark:text-slate-500">
                <span key={rotateIndex} className={`absolute inset-0 block leading-7 truncate ${reducedMotion?'':'gees-service-rise'}`}>{ROTATING_SERVICES[rotateIndex]}</span>
              </span>
            </div>}
            <input ref={inputRef} value={query} onChange={e=>{setQuery(e.target.value);setServicesOpen(true);setFilterOpen(null)}} onFocus={()=>setFocused(true)} onBlur={()=>setFocused(false)} onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();const exact=ROTATING_SERVICES.find(s=>s.toLowerCase()===query.trim().toLowerCase());if(exact)navigateService(exact);else runSearch();}}} aria-label="Search GEES services" className="relative w-full h-full min-w-0 bg-transparent outline-none text-sm sm:text-base text-slate-900 dark:text-white placeholder:text-slate-400" placeholder={focused?'Search services...':''}/>
          </div>
          {query&&<button aria-label="Clear search" onClick={()=>{setQuery('');inputRef.current?.focus();}} className="p-1.5 text-slate-400 hover:text-slate-700"><X size={17}/></button>}
          <button aria-label="Voice search" title="Voice search" onClick={()=>{setFeedback('Voice input requires connecting the existing microphone provider.');}} className="p-2 text-slate-500 hover:text-amber-600 rounded-lg focus-visible:outline-2 focus-visible:outline-amber-500"><Mic size={19}/></button>
          <button aria-label="Browse all services" aria-expanded={servicesOpen} onClick={()=>{setServicesOpen(v=>!v);setFilterOpen(null);}} className="p-2 text-slate-500 hover:text-amber-600 rounded-lg focus-visible:outline-2 focus-visible:outline-amber-500">{servicesOpen?<ChevronUp size={19}/>:<ChevronDown size={19}/>}</button>
        </div>
        {servicesOpen&&<div className="border-t border-slate-100 dark:border-slate-700 mt-3 pt-3">
          <div className="flex gap-1.5 flex-wrap mb-2">{['All',...Object.keys(GROUPS)].map(g=><button key={g} onClick={()=>setCategory(g)} className={`rounded-md px-2.5 py-1.5 text-xs ${category===g?'bg-[#152C50] text-white':'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'}`}>{g}</button>)}</div>
          <div className="max-h-[190px] overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-0.5 [scrollbar-width:thin]">{matchingServices.map(item=><button key={item} onClick={()=>navigateService(item)} className="text-left text-sm p-2.5 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200">{item}</button>)}{matchingServices.length===0&&<span className="text-sm text-slate-500 p-2">No matching services</span>}</div>
        </div>}
      </div>
      <div className="border-t border-slate-100 dark:border-slate-800 px-3 sm:px-5">
        <div role="tablist" aria-label="Search categories" className="flex items-center gap-5 sm:gap-8 overflow-x-auto [scrollbar-width:none]">
          {(['Courses','Scholarships','Universities','All Services'] as Tab[]).map(t=><button key={t} role="tab" aria-selected={tab===t} onClick={()=>changeTab(t)} className={`relative whitespace-nowrap py-3.5 text-[13px] sm:text-sm font-semibold transition-colors ${tab===t?'text-[#152C50] dark:text-white':'text-slate-400 hover:text-slate-700'}`}>{t}{tab===t&&<span className="absolute bottom-0 left-0 right-0 h-[3px] rounded-t bg-amber-400"/>}</button>)}
        </div>
      </div>
      <div className="px-3 sm:px-5 pb-3.5 pt-3 grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        {tab==='Universities'?<label className="h-16 rounded-xl border border-slate-200 dark:border-slate-700 px-3.5 flex flex-col justify-center min-w-0"><span className="text-[10px] tracking-wider uppercase font-semibold text-slate-400">University</span><input list="gees-university-options" value={university} onChange={e=>setUniversity(e.target.value)} placeholder="University name" className="text-[15px] bg-transparent w-full min-w-0 outline-none text-slate-800 dark:text-white"/><datalist id="gees-university-options">{UNIVERSITIES.map(u=><option key={u} value={u}/>)}</datalist></label>:tab!=='All Services'?renderFilter('level','Study Level','All Levels'):null}
        {tab!=='All Services'&&renderFilter('destination','Destination','All Destinations')}
        {tab==='Courses'&&renderFilter('field','Field','All Fields')}
        {tab==='All Services'&&<div className="col-span-1 sm:col-span-1 lg:col-span-3 flex items-center text-sm text-slate-500">Select or search any GEES service above.</div>}
        <button type="button" onClick={runSearch} className={`h-16 rounded-xl bg-[#152C50] hover:bg-[#21436B] text-white inline-flex gap-2 items-center justify-center font-semibold text-[15px] transition-colors focus-visible:outline-2 focus-visible:outline-amber-500 ${tab==='Scholarships'||tab==='Universities'?'lg:col-start-4':''}`}><Search size={18}/> Search</button>
      </div>
    </div>
    {feedback&&<div role="status" className="text-xs text-slate-600 mt-2">{feedback}</div>}
  </div>;
};
